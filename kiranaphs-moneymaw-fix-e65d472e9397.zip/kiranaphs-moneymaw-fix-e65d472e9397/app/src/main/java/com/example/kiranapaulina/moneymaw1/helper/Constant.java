package com.example.kiranapaulina.moneymaw1.helper;

import android.app.Activity;
import android.view.Window;

public class Constant {
    public static final int HEADER = 0;
    public static final String KEY_DATA = "KEY_DATA";

    public static final double IDRTOUSD = 14300;
    public static final double IDRTORIEL = 3.54;
    public static final double IDRTOSGD = 10496;
    public static final double IDRTO1KB = 901;
    public static final double IDRTOBAHT = 440;
    public static final double IDRTORINGGIT = 3442;
}
