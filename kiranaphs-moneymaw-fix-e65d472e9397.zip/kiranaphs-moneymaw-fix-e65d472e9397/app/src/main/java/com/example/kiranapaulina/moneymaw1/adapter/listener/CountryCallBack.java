package com.example.kiranapaulina.moneymaw1.adapter.listener;

import com.example.kiranapaulina.moneymaw1.model.CountryModel;

public interface CountryCallBack {
    void onCountryCallBack(CountryModel countryModel);
}
