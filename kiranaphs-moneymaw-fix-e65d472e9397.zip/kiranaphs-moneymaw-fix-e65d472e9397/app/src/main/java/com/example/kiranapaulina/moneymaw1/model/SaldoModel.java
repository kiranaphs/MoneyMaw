package com.example.kiranapaulina.moneymaw1.model;

public class SaldoModel {

    double saldo;

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}
