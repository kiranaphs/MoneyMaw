package com.example.kiranapaulina.moneymaw1.adapter.listener;

import com.example.kiranapaulina.moneymaw1.model.JournalModel;

public interface DataCallBack {
    void onClicked(JournalModel data);
}
